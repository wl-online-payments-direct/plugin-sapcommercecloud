/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 4 Jul 2025, 12:09:46                        ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2025 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.spartacussampledata.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedSpartacussampledataConstants
{
	public static final String EXTENSIONNAME = "spartacussampledata";
	
	protected GeneratedSpartacussampledataConstants()
	{
		// private constructor
	}
	
	
}
