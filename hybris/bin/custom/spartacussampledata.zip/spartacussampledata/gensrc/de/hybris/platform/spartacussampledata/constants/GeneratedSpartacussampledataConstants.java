/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 27 Feb 2026, 15:33:17                       ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2026 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.spartacussampledata.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedSpartacussampledataConstants
{
	public static final String EXTENSIONNAME = "spartacussampledata";
	
	protected GeneratedSpartacussampledataConstants()
	{
		// private constructor
	}
	
	
}
